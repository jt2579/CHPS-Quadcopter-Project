namespace AR.Drone.Client.Video.Native
{
    public enum parrot_video_encapsulation_frametypes_t
    {
        FRAME_TYPE_UNKNNOWN,
        FRAME_TYPE_IDR_FRAME,
        FRAME_TYPE_I_FRAME,
        FRAME_TYPE_P_FRAME,
        FRAME_TYPE_HEADERS,
    }
}