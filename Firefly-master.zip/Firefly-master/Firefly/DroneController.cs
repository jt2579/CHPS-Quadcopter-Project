﻿using AR.Drone.Client;
using AR.Drone.Client.Command;
using AR.Drone.Data.Navigation;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Firefly
{
    class droneController
    {
        public class DroneCommandChangedEventArgs
        {
            public string CommandText { get; set; }
        }

        public delegate void DroneCommandChangedDelegate(object sender, DroneCommandChangedEventArgs args);

        public event DroneCommandChangedDelegate DroneCommandChanged;

        private DroneClient _client;

        public droneController()
        {
            _client = new DroneClient("192.168.1.1");
        }

        public droneController(DroneClient client)
        {
            _client = client;
        }

        public void Start()
        {
            _client.Start();
            _client.FlatTrim();
        }

        public void Takeoff()
        {
            _client.Takeoff();
        }

        public void Land()
        {
            _client.Land();
        }

        public void Stop()
        {
            _client.Stop();
        }

        public void Emergency()
        {
            _client.Emergency();
        }

        public void ResetEmergency()
        {
            _client.ResetEmergency();
        }

        public void SubscribeToGestures()
        {
            // Right Hand
            GestureDetection.RightHandUpDownChanged += GestureDetection_RightHandUpDownChanged;
            GestureDetection.RightHandLeftRightChanged += GestureDetection_RightHandLeftRightChanged;
            GestureDetection.RightHandBackForwardsChanged += GestureDetection_RightHandBackForwardsChanged;

            // Left Hand
            GestureDetection.LeftHandUpDownChanged += GestureDetection_LeftHandUpDownChanged;
            GestureDetection.LeftHandLeftRightChanged += GestureDetection_LeftHandLeftRightChanged;
            GestureDetection.LeftHandBackForwardsChanged += GestureDetection_LeftHandBackForwardsChanged;
        }

        void GestureDetection_LeftHandBackForwardsChanged(object sender, HandPositionChangedArgs args)
        {
            switch (args.Position)
            {
                case HandPosition.Center:
                    break;
                case HandPosition.Backwards:
                    if (_client.NavigationData.State == (NavigationState.Landed | NavigationState.Command))
                        _client.FlatTrim();
                    DroneCommandChanged(_client, new DroneCommandChangedEventArgs { CommandText = "Flat Trim " });
                    break;
                case HandPosition.Forwards:
                    _client.Hover();
                    DroneCommandChanged(_client, new DroneCommandChangedEventArgs { CommandText = "Hover" });
                    break;
            }
        }

        void GestureDetection_RightHandBackForwardsChanged(object sender, HandPositionChangedArgs args)
        {
            switch (args.Position)
            {
                case HandPosition.Center:
                    // if shoulder is not moving backwards or forwards then human isn't moving
                    // so the drone should stay in place, so it should hover
                    _client.Hover();
                    break;
                case HandPosition.Backwards:
                    _client.Progress(FlightMode.Progressive, pitch: 0.05f);
                    DroneCommandChanged(_client, new DroneCommandChangedEventArgs { CommandText = "Moving Backwards" });
                    break;
                case HandPosition.Forwards:
                    _client.Progress(FlightMode.Progressive, pitch: -0.05f);
                    DroneCommandChanged(_client, new DroneCommandChangedEventArgs { CommandText = "Moving Forwards" });
                    break;
            }
        }

        void GestureDetection_RightHandLeftRightChanged(object sender, HandPositionChangedArgs args)
        {
            switch (args.Position)
            {
                case HandPosition.Center:
                    _client.Hover();
                    break;
                case HandPosition.Left:
                    // _client.Progress(FlightMode.Progressive, roll: -0.05f);
                    // DroneCommandChanged(_client, new DroneCommandChangedEventArgs { CommandText = "Rolling to the Left" });
                    _client.Start();
                    _client.Takeoff();
                    DroneCommandChanged(_client, new DroneCommandChangedEventArgs { CommandText = "Start Up and Take off" });
                    break;
                case HandPosition.Right: // We want this to read the shoulder moving to the right so the drone can follow
                  _client.Progress(FlightMode.Progressive, roll: 0.05f);
                    DroneCommandChanged(_client, new DroneCommandChangedEventArgs { CommandText = "Roll to the Right" });
                    break;
            }
        }

        void GestureDetection_LeftHandLeftRightChanged(object sender, HandPositionChangedArgs args)
        {
            switch (args.Position)
            {
                case HandPosition.Center:
                    _client.Hover();
                    break;
                case HandPosition.Left: //roll left
                  _client.Progress(FlightMode.Progressive, roll: -0.05f);
                    break;
                case HandPosition.Right://Left hand moving to the right causes the drone to land
                    // _client.Progress(FlightMode.Progressive, yaw: -0.25f);
                    //DroneCommandChanged(_client, new DroneCommandChangedEventArgs { CommandText = "Turning Right" });
                    _client.Land();
                    DroneCommandChanged(_client, new DroneCommandChangedEventArgs { CommandText = "Landing" });
                    //want to use _client.Stop() but it needs a delay instead of stopping and not being able to read land()
                    break;
            }
        }

        void GestureDetection_RightHandUpDownChanged(object sender, HandPositionChangedArgs args)
        {
            switch (args.Position)
            {
                case HandPosition.Up:
                    //_client.Progress(FlightMode.Progressive, gaz: 0.25f);
                    // fly upwards was original command
                    // Want the Drone to turn right 360 deg 
                    // like a dance move with the right hand up
                    _client.Progress(FlightMode.Progressive, yaw: -1f);
                    DroneCommandChanged(_client, new DroneCommandChangedEventArgs { CommandText = "Spinning Right" });
                    break;
                case HandPosition.Center:
                    break;
               // case HandPosition.Down:
                 //   _client.Progress(FlightMode.Progressive, gaz: -0.25f);
                   // DroneCommandChanged(_client, new DroneCommandChangedEventArgs { CommandText = "Going Down" });
                    //break;
            }
        }

        void GestureDetection_LeftHandUpDownChanged(object sender, HandPositionChangedArgs args)
        {
            switch (args.Position)
            {
                case HandPosition.Up:
                    // Original:
                    // _client.Takeoff(); 
                    _client.Progress(FlightMode.Progressive, yaw: 1f);
                    DroneCommandChanged(_client, new DroneCommandChangedEventArgs { CommandText = "Spinning Left" });
                    // Left hand up makes Drone turn left 360 deg
                    
                    break;
                case HandPosition.Center:
                    break;
                case HandPosition.Down:
               //     _client.Land();
                 //   DroneCommandChanged(_client, new DroneCommandChangedEventArgs { CommandText = "Landing" });
                    break;
            }
        }
    }
}
