# Firefly

**Tutorial: Fly your Parrot AR.Drone 2.0 with a Kinect for Windows**

Please refer to: http://sebastianbrandes.com/2014/12/tutorial-parrot-ar-drone-kinect

## Ruslan-B/AR.Drone

This solution uses some of the code from the Ruslan-B/AR.Drone repository.

Check it out: https://github.com/Ruslan-B/AR.Drone
