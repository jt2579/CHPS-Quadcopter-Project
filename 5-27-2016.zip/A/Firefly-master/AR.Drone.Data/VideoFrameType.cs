namespace AR.Drone.Data
{
    public enum VideoFrameType : byte
    {
        Unknown,
        I,
        P
    }
}