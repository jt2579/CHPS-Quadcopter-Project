namespace AR.Drone.Client.Command
{
    public enum Device
    {
        Magnetometer = 0
    }
}