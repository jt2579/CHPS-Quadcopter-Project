﻿namespace AR.Drone.Client
{
    internal enum StateRequest
    {
        None,
        Land,
        Fly,
        Emergency,
        ResetEmergency
    }
}