namespace AR.Drone.Client.Configuration
{
    public enum UserboxCommandType
    {
        Stop = 0,
        Start,
        Screenshot,
        Cancel,
        Max,
    }
}